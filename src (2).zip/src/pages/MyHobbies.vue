<template>
    
 <img
      alt="Quasar logo"
      src="~../assets/beautiful-indian-classical-dance-bharatanatyam-woman-dancer-original-imafmqmqm77saegw.webp"
      style="width: 200px; height: 200px" 
      
    >    
     <img
      alt="Quasar logo"
      src="..\assets\carvaanframe_10_1672650646.webp"
      style="width: 200px; height: 200px" 
      
    > 
    <img
    src="..\assets\download (1).jpg"
      style="width: 200px; height: 200px"
      >
     <img
    src="..\assets\download (2).jpg"
      style="width: 200px; height: 200px"
      >



<ul>
<li>   
<h5> Dancing has always been my passion </h5></li>
<li>
<h5> I love to travel and explore the authenticity of the culture </h5></li>
<li><h5> Movies are on the top list along with Photography </h5></li>
<li><h5> Listening to Retro and Classical music is always a cure for me </h5>
</li>
</ul>


      
      

</template>

