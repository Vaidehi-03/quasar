
<template>
<q-parallax
src=~..\assets\om-symbol-beach-18928608.webp>
 <p style ="font-size:25px">
 Name : Vaidehi Joshi <br>
 Age : 22 <br>
 Post: Graduate Trainee <br>
 Email: Vaidehi.Joshi1@ltimindtree.com  <br>
 Mobile no : 9890390619
  </p>
</q-parallax>


    
  





</template>



