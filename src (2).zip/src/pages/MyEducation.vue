<template>

<q-page class="flex flex-center"  style="
    display: flex;
  flex-direction: column;
  align-items: center; /* Centers content horizontally */
  "
  >


<div class="box">
 





<h6><b><marquee direction="right" bgcolor=skyblue >School: St Mira's Secondary School,Pune </marquee></b></h6>

<h6><b> <marquee direction="right" bgcolor=skyblue>College: Sinhgad Academy ,Pune </marquee></b></h6>

<h6><b> <marquee direction="right" bgcolor=skyblue>Company: LTIMindtree,Coimbatore</marquee> </b></h6>






</div>
</q-page>


</template>


