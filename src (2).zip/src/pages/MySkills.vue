<template>
<q-parallax
        src="~..\assets\laptop-mockup-simple-clean-desk-brick-wall-background-isolated-screen-ap-web-site-resentation-plant-cup-166520507.webp">
<h5><b> Technical Skills : </b> </h5>
<h7> HTML/CSS </h7>
<h7> Python </h7>
<h7> Networks </h7>
<h7> Docker-Kubernetes </h7>
<h7> AI-Ml </h7>
</q-parallax>
</template>