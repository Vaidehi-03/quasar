<template>


  
  <q-page class="flex flex-center cont" style="
    display: flex;
  flex-direction: column;
  align-items: center; /* Centers content horizontally */
  "
  >
  <div class="box">
    <img
      alt="Quasar logo"
      src="~..\assets\Picture1.jpg"
      style="width: 200px; height: 200px"
      
    >
      <h2><font color="white"> Vaidehi.R.Joshi  </font> </h2> 
      </div>
  </q-page>


 
  
   
</template>


<script>
import { defineComponent } from 'vue'

export default defineComponent({
  name: 'IndexPage'
})
</script>

<style scoped>
.cont{
  background-image:url('../assets/jonatan-pie-3l3RwQdHRHg-unsplash.jpg');
}
.box {
  width: 220px;
  height: 250px;
  border: 1px solid black;
  padding: 6px;
  margin: 6px;
}
</style>