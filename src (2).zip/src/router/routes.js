
const routes = [
  {
    path: '/vaidehi',
    component: () => import('layouts/MainLayout.vue'),
    children: [
      { path: '', component: () => import('pages/IndexPage.vue') },
      { path: 'MyProfile', component: () => import('pages/MyProfile.vue') },
      { path: 'MyEducation', component: () => import('pages/MyEducation.vue') },
      { path: 'MyHobbies', component: () => import('pages/MyHobbies.vue') },
      { path: 'MySkills', component: () => import('pages/MySkills.vue') },



    ]
  },
  // {
  //   path: '/MyProfile',
  //   component: () => import('layouts/MainLayout.vue'),
  //   children: [
  //     { path: '', component: () => import('pages/MyProfile.vue') }
  //   ]
  // },

  // {
  //   path: '/MyEducation',
  //   component: () => import('layouts/MainLayout.vue'),
  //   children: [
  //     { path: '', component: () => import('pages/MyEducation.vue') }
  //   ]
  // },

  // {
  //   path: '/MyHobbies',
  //   component: () => import('layouts/MainLayout.vue'),
  //   children: [
  //     { path: '', component: () => import('pages/MyHobbies.vue') }
  //   ]
  // },

  //   {
  //   path: '/MySkills',
  //   component: () => import('layouts/MainLayout.vue'),
  //   children: [
  //     { path: '', component: () => import('pages/MySkills.vue') }
  //   ]
  // },



  // Always leave this as last one,
  // but you can also remove it
  {
    path: '/:catchAll(.*)*',
    component: () => import('pages/ErrorNotFound.vue')
  }
]

export default routes
