<template>
  <q-item
    clickable
    tag="a"
    target="_blank"
    :href="link"
  >
    <q-item-section>
      <q-btn>
      <router-link to="/vaidehi/MyProfile"> {{title1}}</router-link>
      
      </q-btn>

      <q-btn>
      <router-link to="/vaidehi/MyEducation"> {{title2}}</router-link>
      </q-btn>

      

      <q-btn>
      <router-link to="/vaidehi/MyHobbies"> {{title3}}</router-link>
      </q-btn>

      <q-btn>
      <router-link to="/vaidehi/MySkills"> {{title4}}</router-link>
      </q-btn>

    </q-item-section>
    </q-item>
    </template>




<script>
import { defineComponent } from 'vue'

export default defineComponent({
  name: 'EssentialLink',
  props: {
    title1: {
      type: String,
      required: true
    },
    
    title2: {
      type: String,
      required: true
    },
    

    title3: {
      type: String,
      required: true
    },
    
    title4: {
      type: String,
      required: true
    },
    
   
  }
})


    
</script>
